//This page is extra not most importand part in here


import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.chrome.ChromeDrive;
import org.testing.annotations.Test;
//𒀀𒀸𒋗 - Assu - Good,Dear
import com.github.lalyos.jfiglet.FigletFont;
import org.openqa.selenium.remote.CapabilityType;

import java.net.URL;
class Main {

    public static void main(String... args) throws Exception {
 
  //public void webAddresOpen () {
     //WebDriver driver =new ChromeDriver();

    //driver.manager().window().maximize();




    
  }      
      
      
      
      // System.out.println(FigletFont.convertOneLine(
              // "Hey " + ((args.length>0)?args[0]:"jbang")));  ;;    
    }
}
